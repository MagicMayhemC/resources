﻿function setPlayerFreecamEnabled(player, x, y, z, dontChangeFixedMode)
	return triggerClientEvent(player,"doSetFreecamEnabled", getRootElement(), x, y, z, dontChangeFixedMode)
end

function setPlayerFreecamDisabled(player, dontChangeFixedMode)
	return triggerClientEvent(player,"doSetFreecamDisabled", getRootElement(), dontChangeFixedMode)
end

function setPlayerFreecamOption(player, theOption, value)
	return triggerClientEvent(player,"doSetFreecamOption", getRootElement(), theOption, value)
end

function isPlayerFreecamEnabled(player)
	return getElementData(player,"freecam:state")
end

function enableFreecam (player)
    if (not isPlayerFreecamEnabled (player)) then
        local x, y, z = getElementPosition (player)
        setPlayerFreecamEnabled (player, x, y, z)
    else
        setPlayerFreecamDisabled (player)
    end
end
addCommandHandler ('freecam', enableFreecam)

function getpos( plr )
	local x, y, z, x2, y2, z2 = getCameraMatrix( plr )
	outputChatBox( x .. ", " .. y .. ", " .. z .. ", " .. x2 .. ", " .. y2 .. ", " .. z2, plr )
end
addCommandHandler ('campos', getpos)